<?php

return [
    'name' => 'Category',
];
