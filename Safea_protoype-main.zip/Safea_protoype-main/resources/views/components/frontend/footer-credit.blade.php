<div class="py-6">
    <span class="text-sm text-gray-500 dark:text-gray-400 sm:text-center">{!! setting("footer_text") !!}</span>
</div>
