<li class="breadcrumb-item">
    <a href="{{ route("backend.dashboard") }}">
        <i class="fa-solid fa-cubes"></i>
        <span class="d-none d-sm-inline-block">&nbsp;{{ __("Dashboard") }}</span>
    </a>
</li>

{!! $slot !!}
